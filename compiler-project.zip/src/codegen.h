#include "tree.h"

void genProgram(STMT_LIST *root, char *name);